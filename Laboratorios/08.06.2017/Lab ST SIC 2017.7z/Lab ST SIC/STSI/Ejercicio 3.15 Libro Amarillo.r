
#Ejercicio 3.15 Libro Amarillo

rm(list=ls(all=TRUE))

library(survey)
library(sampling)

data(MU284)

# S82  Total de ediles de la municipalidad
# CS82 Total de ediles conservadores de la municipalidad
# SS82 Total de ediles social demócratas de la municipalidad

sum(MU284$SS82)

# crea la variable estrato
MU284$ST=cut(MU284$S82,
             breaks= c(30,40,50,70,101) # limites de los estratos
             )

(Nh=table(MU284$ST))

(TS82=aggregate(MU284$S82,
               list(S82=MU284$ST),
               sum))
(SDS82=aggregate(MU284$S82,
                list(S82=MU284$ST),
                sd))

n=40 #tama�o de muestra total
#asignacion proporcional
(nhprop=round(n*Nh/sum(Nh),0))
sum(nhprop)
#tasas de muestreo por estrato
round(nhprop/Nh,2)

#asignaci�n optima
(nhopt=round(n*Nh*SDS82$x/sum(Nh*SDS82$x),0))
#tasas de muestreo por estrato
round(nhopt/Nh,2)
sum(nhopt)


#pega los tama�os de los estratos en MU284
MU284$Nh[MU284$ST=="(30,40]"] =Nh[1]
MU284$Nh[MU284$ST=="(40,50]"] =Nh[2]
MU284$Nh[MU284$ST=="(50,70]"] =Nh[3]
MU284$Nh[MU284$ST=="(70,101]"]=Nh[4]

#PEGA EL TAMA�O DE LA POBLACION
MU284$N=284
View(MU284)


set.seed(21062016)

s=sample(1:284, #etiquetas
          n, # n muestra
          replace = FALSE) # sin remplazo 

s=MU284[s,]

# Para sacar muestras estratificadas conviene primero ordenar la base
#para asegurarse que el primer estrato es el primer estrato, etc.

MU284=MU284[order(MU284$S82),]

sprop=strata(MU284, #marco
             "ST", #estrato
             nhprop, # tama�os de muestra
             method=c("srswor"), # dise�o por estrato
             description=TRUE)
sprop=getdata(MU284,sprop)
View(sprop)
Nh
nhprop

sopt=strata(MU284,
            "ST",
            nhopt, 
            method=c("srswor"),
            description=TRUE)
sopt=getdata(MU284,sopt)
Nh
nhopt

#carga la muestra SI
pSI=svydesign(id=~1,
              fpc=s$N,
              data=s)

svytotal(~SS82,pSI, deff=TRUE)

#carga dise�o muestra STSI prop
pSTSIprop=svydesign(id=~1,
                    strata=~ST,
                    fpc=~Nh,
                    data=sprop)
# otra forma
pSTSIprop=svydesign(id=~1,
                    strata=~ST,
                    fpc=~ Prob,
                    probs = ~ Prob,
                    data=sprop)

svytotal(~SS82,pSTSIprop, deff=TRUE)

svyby(~SS82, ~ST, pSTSIprop, svytotal, deff=TRUE)

pSTSIopt=svydesign(id=~1,
                   strata=~ST,
                   fpc=~Nh,
                   data=sopt)

svytotal(~SS82,pSTSIopt, deff=TRUE)
svyby(~SS82, ~ST, pSTSIopt, svytotal, deff=TRUE)

#¿Cómo puede ser que el Deff con asignación óptima de más alto que con
#asignación proporcional?

########## Muchos Estratos

MU284=MU284[order(MU284$S82),]
MU284$ST=c(rep(c(1:2),rep(16,2)),rep(c(3:20),rep(14,18)))
table(MU284$ST)
s20=strata(MU284, "ST", rep(2,20), method=c("srswor"),description=TRUE)
s20=getdata(MU284,s20)

s20$Nh=c(16,16,rep(14,18))

pSTSI20=svydesign(id=~1,strata=~ST,fpc=~Nh,data=s20)
svytotal(~SS82,pSTSI20, deff=TRUE)

#Construccion de estratos

library(stratification)
n=40
Ls=4
ST=strata.cumrootf(MU284$S82,
                   n=n,
                   Ls=Ls,
                   nclass=284)
ST

# En el excel está hecho a mano.

MU284$STDH<-ST$stratumID

for (i in 1:Ls)
  {
MU284$Nh[MU284$STDH==i]<-ST$Nh[i]
  }

MU284<-MU284[order(MU284$STDH),]

set.seed(1)
sDH=strata(MU284, "STDH", ST$nh , method=c("srswor"),description=TRUE)
sDH=getdata(MU284,sDH)


pSTSIDH=svydesign(id=~1, strata=~STDH, fpc=~Nh, data=sDH)
svytotal(~SS82, pSTSIDH, deff=TRUE)


########################